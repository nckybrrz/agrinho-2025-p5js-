
 function setup() {
  createCanvas(600, 400);
  noStroke(); // Remover contornos das formas
}

function draw() {
  background(220); // Cor de fundo cinza clara

  // Desenhar o campo na metade esquerda
  desenharCampo(0, 0, width / 2, height);

  // Desenhar a cidade na metade direita
  desenharCidade(width / 2, 0, width / 2, height);
}function desenharCampo(x, y, largura, altura) {
  // Céu azul claro
  fill(135, 206, 235);
  rect(x, y, largura, altura * 0.6);

  // Grama verde
  fill(34, 139, 34);
  rect(x, y + altura * 0.6, largura, altura * 0.4);

  // Sol amarelo
  fill(255, 255, 0);
  ellipse(x + largura * 0.2, y + altura * 0.2, 50, 50);

  // Exemplo de uma montanha
  fill(139, 69, 19);
  triangle(x + largura * 0.8, y + altura * 0.6, x + largura, y + altura * 0.6, x + largura * 0.9, y + altura * 0.3);
}function desenharCidade(x, y, largura, altura) {
  // Cor de fundo da cidade (cinza)
  fill(105, 105, 105);
  rect(x, y, largura, altura);

  // Desenhar alguns prédios
  fill(80, 80, 80);
  rect(x + largura * 0.1, y + altura * 0.7, largura * 0.2, altura * 0.3);
  rect(x + largura * 0.4, y + altura * 0.5, largura * 0.15, altura * 0.5);
  rect(x + largura * 0.7, y + altura * 0.6, largura * 0.25, altura * 0.4);

  // Desenhar janelas (pequenos retângulos amarelos)
  fill(255, 255, 240);
  let larguraJanela = largura * 0.03;
  let alturaJanela = altura * 0.05;
  let espacamentoX = largura * 0.05;
  let espacamentoY = altura * 0.07;

  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 2; j++) {
      rect(x + largura * 0.1 + espacamentoX * i, y + altura * 0.7 + espacamentoY * j, larguraJanela, alturaJanela);
    }
  }

  for (let i = 0; i < 2; i++) {
    for (let j = 0; j < 4; j++) {
      rect(x + largura * 0.4 + espacamentoX * i, y + altura * 0.5 + espacamentoY * j, larguraJanela, alturaJanela);
    }
  }

  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      rect(x + largura * 0.7 + espacamentoX * i, y + altura * 0.6 + espacamentoY * j, larguraJanela, alturaJanela);
    }
  }
}